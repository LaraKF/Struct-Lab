import Foundation
/*:
 ## Struct Lab - Tuwaiq Bootcamp

 Create a struct called Book that contains the following properties:

 - title: a String representing the title of the book
 - author: a String representing the author of the book
 - pages: an integer representing the number of pages in the book
 - topic: a String representing the topic or genre of the book (e.g. Computer Science, Programming, Self-Development, etc.)
 
 */
struct Book{
    var title: String
    var author: String
    var pages: Int
    var topic: String


    init(title: String, author: String, pages: Int, topic: String){
        self.title = title
        self.author = author
        self.pages = pages
        self.topic = topic
    }
}
/*:
 Create an array of type Book and populate it with at least 3 books using a loop.
 */

var b1 = Book(title: "Modern Operating Systems", author: "Andrew S", pages: 500, topic: "Computer Science")
var b2 = Book(title: "Effective Java", author: "Joshua Bloch", pages: 700, topic: "Programming")
var b3 = Book(title: "Thinking, Fast and Slow ", author: "Daniel Kahneman", pages: 600, topic: "Self-Development")

var book = [b1, b2, b3]

for i in book {
    print(i)
}
/*:
 Then, write a function called printBooksInTopic that takes two arguments: the array of books and a topic as a String. The function should print out the title and author of each book in the array that matches the specified topic.
 */

// Example usage:
// printBooksInTopic(books, topic: "Programming")

// Example usage:
//printBooksInTopic(books, topic: "Programming")

//Output
/*
 Clean Code: A Handbook of Agile Software Craftsmanship by Robert C. Martin
 Cracking the Coding Interview: 189 Programming Questions and Solutions by Gayle Laakmann McDowell
 */
func printBooksInTopic(books: String , topic: String){
    
    if topic == b2.topic {
        print("\(books) by \(b2.author)")
    }
    else if topic == b1.topic {
        print("\(books) by \(b1.author)")
    }
            else {
                print("\(books) by \(b3.author)")
            }
}

printBooksInTopic(books: "Effective Java", topic: "Programming")
printBooksInTopic(books: "Modern Operating Systems", topic: "Computer Science")
